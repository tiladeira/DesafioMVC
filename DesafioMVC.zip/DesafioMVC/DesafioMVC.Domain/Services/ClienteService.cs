﻿using DesafioMVC.Domain.Entities;
using DesafioMVC.Domain.Interfaces.Base;
using DesafioMVC.Domain.Interfaces.Repositories;
using DesafioMVC.Domain.Interfaces.Services;

using System.Linq.Expressions;

namespace DesafioMVC.Domain.Services
{
    public class ClienteService : BaseService, IClienteService
    {
        private readonly IUnitOfWorkRepository _unitOfWork;

        public ClienteService(IUnitOfWorkRepository unitOfWork, INotificador notificador) : base(notificador)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> AdicionarAsync(Cliente entity)
        {
            await _unitOfWork.Clientes.AdicionarAsync(entity);
            return await _unitOfWork.SaveAsync();
        }

        public async Task<bool> AtualizarAsync(Cliente entity)
        {
            var itemExistente = await ObterPorIdAsync(entity.Id);

            if (itemExistente == null)
            {
                Notificar("Item não encontrado");
                return false;
            }

            await _unitOfWork.Clientes.AtualizarAsync(itemExistente);
            return await _unitOfWork.SaveAsync();
        }

        public async Task<IEnumerable<Cliente>> BuscarAsync(Expression<Func<Cliente, bool>> predicate)
        {
            return await _unitOfWork.Clientes.BuscarAsync(predicate);
        }

        public async Task<bool> DeletarAsync(int id)
        {
            var entity = await ObterPorIdAsync(id);

            if (entity != null)
            {
                await _unitOfWork.Clientes.DeletarAsync(entity).ConfigureAwait(false);
                return await _unitOfWork.SaveAsync();
            }

            return false;
        }

        public async Task<IEnumerable<Cliente>> ObterAsync()
        {
            return await _unitOfWork.Clientes.ObterAsync();
        }

        public async Task<Cliente> ObterPorIdAsync(int id)
        {
            var entity = await _unitOfWork.Clientes.ObterPorIdAsync(id);

            if (entity == null)
            {
                Notificar("Item não encontrado");
                return null;
            }
            return entity;
        }
    }
}
