﻿using DesafioMVC.Domain.Entities;
using DesafioMVC.Domain.Interfaces.Base;
using DesafioMVC.Domain.Interfaces.Repositories;
using DesafioMVC.Domain.Interfaces.Services;

using System.Linq.Expressions;

namespace DesafioMVC.Domain.Services
{
    public class LogradouroService : BaseService, ILogradouroService
    {
        private readonly IUnitOfWorkRepository _unitOfWork;

        public LogradouroService(IUnitOfWorkRepository unitOfWork, INotificador notificador) : base(notificador)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> AdicionarAsync(Logradouro entity)
        {
            await _unitOfWork.Logradouros.AdicionarAsync(entity);
            return await _unitOfWork.SaveAsync();
        }

        public async Task<bool> AtualizarAsync(Logradouro entity)
        {
            var itemExistente = await ObterPorIdAsync(entity.Id);

            if (itemExistente == null)
            {
                Notificar("Item não encontrado");
                return false;
            }

            await _unitOfWork.Logradouros.AtualizarAsync(itemExistente);
            return await _unitOfWork.SaveAsync();
        }

        public async Task<IEnumerable<Logradouro>> BuscarAsync(Expression<Func<Logradouro, bool>> predicate)
        {
            return await _unitOfWork.Logradouros.BuscarAsync(predicate);
        }

        public async Task<bool> DeletarAsync(int id)
        {
            var entity = await ObterPorIdAsync(id);

            if (entity != null)
            {
                await _unitOfWork.Logradouros.DeletarAsync(entity).ConfigureAwait(false);
                return await _unitOfWork.SaveAsync();
            }

            return false;
        }

        public async Task<IEnumerable<Logradouro>> ObterAsync()
        {
            return await _unitOfWork.Logradouros.ObterAsync();
        }

        public async Task<Logradouro> ObterPorIdAsync(int id)
        {
            var entity = await _unitOfWork.Logradouros.ObterPorIdAsync(id);

            if (entity == null)
            {
                Notificar("Item não encontrado");
                return null;
            }
            return entity;
        }
    }
}
