﻿using DesafioMVC.Domain.Entities;
using DesafioMVC.Domain.Interfaces.Repositories;
using DesafioMVC.Domain.Interfaces.Services;

namespace DesafioMVC.Domain.Services
{
    public class LogradouroService : ILogradouroService
    {
        private readonly IUnitOfWorkRepository _unitOfWork;

        public LogradouroService(IUnitOfWorkRepository unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> CreateAsync(Logradouro entity)
        {
            if (entity != null)
            {
                await _unitOfWork.Logradouro.CreateAsync(entity);
                var result = _unitOfWork.Save();

                if (result > 0)
                    return true;
                else
                    return false;
            }

            return false;
        }

        public async Task<bool> DeleteByIdAsync(int id)
        {
            if (id > 0)
            {
                var entity = await _unitOfWork.Logradouro.GetByIdAsync(id);

                if (entity != null)
                {
                    await _unitOfWork.Logradouro.DeleteByAsync(entity).ConfigureAwait(false);
                    var result = _unitOfWork.Save();

                    if (result > 0)
                        return true;
                    else
                        return false;
                }
            }

            return false;
        }

        public async Task<IEnumerable<Logradouro>> GetAllAsync()
        {
            return await _unitOfWork.Logradouro.GetAllAsync();
        }

        public async Task<Logradouro> GetByIdAsync(int id)
        {
            if (id > 0)
            {
                var entity = await _unitOfWork.Logradouro.GetByIdAsync(id);

                if (entity != null)
                    return entity;
            }

            return null;
        }

        public async Task<bool> UpdateAsync(Logradouro entity)
        {
            if (entity != null)
            {
                await _unitOfWork.Logradouro.UpdateAsync(entity);
                var result = _unitOfWork.Save();

                if (result > 0)
                    return true;
                else
                    return false;
            }

            return false;
        }
    }
}
