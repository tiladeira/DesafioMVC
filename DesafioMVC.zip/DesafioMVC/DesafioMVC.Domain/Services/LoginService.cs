﻿using DesafioMVC.Domain.Interfaces.Services;

namespace DesafioMVC.Domain.Services
{
    public class LoginService : ILoginService
    {
        public LoginService()
        {
        }

        public async Task<bool> Login(string usuario, string senha)
        {
            if (usuario == "admin" && senha == "admin")
                return true;
            else
                return false;
        }
    }
}
