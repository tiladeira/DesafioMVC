﻿using DesafioMVC.Domain.Entities;
using DesafioMVC.Domain.Interfaces.Repositories;
using DesafioMVC.Domain.Interfaces.Services;

namespace DesafioMVC.Domain.Services
{
    public class ClienteSisService : IClienteSisService
    {
        private readonly IUnitOfWorkRepository _unitOfWork;

        public ClienteSisService(IUnitOfWorkRepository unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> CreateAsync(ClienteSis entity)
        {
            if (entity != null)
            {
                var existe = _unitOfWork.ClienteSis.GetAllAsync().Result.Any(x => x.Email == entity.Email);

                if (existe)
                    return false;

                await _unitOfWork.ClienteSis.CreateAsync(entity);
                var result = _unitOfWork.Save();

                if (result > 0)
                    return true;
                else
                    return false;
            }

            return false;
        }

        public async Task<bool> DeleteByIdAsync(int id)
        {
            if (id > 0)
            {
                var entity = await _unitOfWork.ClienteSis.GetByIdAsync(id);

                if (entity != null)
                {
                    await _unitOfWork.ClienteSis.DeleteByAsync(entity).ConfigureAwait(false);
                    var result = _unitOfWork.Save();

                    if (result > 0)
                        return true;
                    else
                        return false;
                }
            }

            return false;
        }

        public async Task<IEnumerable<ClienteSis>> GetAllAsync()
        {
            return await _unitOfWork.ClienteSis.GetAllAsync();
        }

        public async Task<ClienteSis> GetByIdAsync(int id)
        {
            if (id > 0)
            {
                var entity = await _unitOfWork.ClienteSis.GetByIdAsync(id);

                if (entity != null)
                    return entity;
            }

            return null;
        }

        public async Task<bool> UpdateAsync(ClienteSis entity)
        {
            if (entity != null)
            {
                await _unitOfWork.ClienteSis.UpdateAsync(entity);
                var result = _unitOfWork.Save();

                if (result > 0)
                    return true;
                else
                    return false;
            }

            return false;
        }
    }
}
