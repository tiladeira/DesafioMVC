﻿namespace DesafioMVC.Domain.Result
{
    public class ResponsePaginacao<TEntity>
    {
        public ResponsePaginacao(TEntity data, int paginaAtual, int totalPaginas, int totalItens)
        {
            PaginaAtual = paginaAtual;
            TotalPaginas = totalPaginas;
            Data = data;
            TotalItens = totalItens;
        }

        public TEntity Data { get; set; }
        public int TotalPaginas { get; set; }
        public int PaginaAtual { get; set; }
        public int TotalItens { get; set; }
    }
}
