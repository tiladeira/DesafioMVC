﻿namespace DesafioMVC.Domain.Entities.Base
{
    public abstract class BaseEntity
    {
        public int Id { get; private set; }
    }
}
