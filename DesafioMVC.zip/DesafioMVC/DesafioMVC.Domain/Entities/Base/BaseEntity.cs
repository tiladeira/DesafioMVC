﻿namespace DesafioMVC.Domain.Entities.Base
{
    public class BaseEntity
    {
        public int Id { get; set; }
    }
}
