﻿using DesafioMVC.Domain.Entities.Base;

namespace DesafioMVC.Domain.Entities
{
    public class ClienteSis : BaseEntity
    {
        public string Nome { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Senha { get; set; } = string.Empty;
        public string Logotipo { get; set; } = string.Empty;
        public bool Status { get; set; }
    }
}
