﻿using DesafioMVC.Domain.Entities;
using DesafioMVC.Domain.Interfaces.Base;

namespace DesafioMVC.Domain.Interfaces.Services
{
    public interface IClienteSisService : IServiceBase<ClienteSis>
    {
    }
}
