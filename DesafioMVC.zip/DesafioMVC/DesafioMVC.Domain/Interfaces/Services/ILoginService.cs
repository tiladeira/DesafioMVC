﻿namespace DesafioMVC.Domain.Interfaces.Services
{
    public interface ILoginService
    {
        Task <bool> Login(string usuario, string senha);
    }
}
