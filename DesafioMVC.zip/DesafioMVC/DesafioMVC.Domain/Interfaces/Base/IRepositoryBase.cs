﻿using DesafioMVC.Domain.Entities.Base;

using System.Linq.Expressions;

namespace DesafioMVC.Domain.Interfaces.Base
{
    public interface IRepositoryBase<TEntity> where TEntity : BaseEntity
    {
        Task<IEnumerable<TEntity>> ObterAsync();
        Task<IEnumerable<TEntity>> BuscarAsync(Expression<Func<TEntity, bool>> predicate);
        Task<TEntity?> ObterPorIdAsync(int id);
        Task AdicionarAsync(TEntity entity);
        Task DeletarAsync(TEntity entity);
        Task AtualizarAsync(TEntity entity);
    }
}
