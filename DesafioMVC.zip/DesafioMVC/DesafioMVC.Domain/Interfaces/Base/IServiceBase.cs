﻿using DesafioMVC.Domain.Entities.Base;
using DesafioMVC.Domain.Result;

using System.Linq.Expressions;

namespace DesafioMVC.Domain.Interfaces.Base
{
    public interface IServiceBase<TEntity> where TEntity : BaseEntity
    {
        Task<IEnumerable<TEntity>> ObterAsync();
        Task<IEnumerable<TEntity>> BuscarAsync(Expression<Func<TEntity, bool>> predicate);
        Task<TEntity> ObterPorIdAsync(int id);
        Task<bool> AdicionarAsync(TEntity entity);
        Task<bool> DeletarAsync(int id);
        Task<bool> AtualizarAsync(TEntity entity);
    }
}
