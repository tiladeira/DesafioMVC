﻿using DesafioMVC.Domain.Entities;
using DesafioMVC.Domain.Interfaces.Base;

namespace DesafioMVC.Domain.Interfaces.Repositories
{
    public interface ILogradouroRepository : IRepositoryBase<Logradouro>
    {
    }
}
