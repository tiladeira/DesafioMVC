﻿namespace DesafioMVC.Domain.Interfaces.Repositories
{
    public interface IUnitOfWorkRepository : IDisposable
    {        
        IClienteSisRepository ClienteSis { get; }
        ILogradouroRepository Logradouro { get; }

        int Save();
    }
}
