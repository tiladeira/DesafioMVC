﻿namespace DesafioMVC.Domain.Interfaces.Repositories
{
    public interface IUnitOfWorkRepository : IDisposable
    {
        IClienteRepository Clientes { get; }
        ILogradouroRepository Logradouros { get; }

        Task<bool> SaveAsync();
    }
}
