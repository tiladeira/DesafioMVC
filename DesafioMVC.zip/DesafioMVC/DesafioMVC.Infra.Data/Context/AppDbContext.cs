﻿using Microsoft.EntityFrameworkCore;

using System.Reflection;

using DesafioMVC.Domain.Entities;

namespace DesafioMVC.Infra.Data.Context
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<ClienteSis>? ClientesSis { get; set; }
        public DbSet<Logradouro>? Logradouros { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        }
    }
}
