﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesafioMVC.Infra.Data.Context
{
    public class AppDbContextDapper
    {
        private readonly IConfiguration _configuration;

        public AppDbContextDapper(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IDbConnection DapperConnection
        {
            get
            {
                return new SqlConnection(_configuration["ConnectionStrings:DefaultConnection"]);
            }
        }
    }
}
