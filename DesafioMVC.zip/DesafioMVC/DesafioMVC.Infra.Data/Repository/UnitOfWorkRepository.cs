﻿using DesafioMVC.Domain.Interfaces.Repositories;
using DesafioMVC.Infra.Data.Context;

namespace DesafioMVC.Infra.Data.Repository
{
    public class UnitOfWorkRepository : IUnitOfWorkRepository
    {
        private readonly AppDbContext _dbContext;

        public IClienteSisRepository ClienteSis { get; }
        public ILogradouroRepository Logradouro { get; }

        public UnitOfWorkRepository(AppDbContext dbContext,
                          IClienteSisRepository clienteSis,
                          ILogradouroRepository logradouro)
        {
            _dbContext = dbContext;
            ClienteSis = clienteSis;
            Logradouro = logradouro;
        }

        public int Save()
        {
            return _dbContext.SaveChanges();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
                _dbContext.Dispose();
        }
    }
}
