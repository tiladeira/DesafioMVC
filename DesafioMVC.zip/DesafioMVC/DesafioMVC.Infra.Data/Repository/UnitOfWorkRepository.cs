﻿using DesafioMVC.Domain.Interfaces.Repositories;
using DesafioMVC.Infra.Data.Context;

namespace DesafioMVC.Infra.Data.Repository
{
    public class UnitOfWorkRepository : IUnitOfWorkRepository
    {
        private readonly AppDbContext _dbContext;

        public IClienteRepository Clientes { get; }
        public ILogradouroRepository Logradouros { get; }

        public UnitOfWorkRepository(AppDbContext dbContext,
                          IClienteRepository clienteRepository,
                          ILogradouroRepository logradouroRepository)
        {
            _dbContext = dbContext;

            Clientes = clienteRepository;
            Logradouros = logradouroRepository;
        }

        public async Task<bool> SaveAsync()
            => await _dbContext.SaveChangesAsync() > 0;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
                _dbContext.Dispose();
        }
    }
}
