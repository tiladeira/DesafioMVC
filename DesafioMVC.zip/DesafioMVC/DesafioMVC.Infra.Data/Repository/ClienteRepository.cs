﻿using DesafioMVC.Domain.Entities;
using DesafioMVC.Domain.Interfaces.Repositories;
using DesafioMVC.Infra.Data.Context;
using DesafioMVC.Infra.Data.Repository.Base;

namespace DesafioMVC.Infra.Data.Repository
{
    public class ClienteRepository : RepositoryBase<Cliente>, IClienteRepository
    {
        public ClienteRepository(AppDbContext appContext) : base(appContext)
        {
        }
    }
}
