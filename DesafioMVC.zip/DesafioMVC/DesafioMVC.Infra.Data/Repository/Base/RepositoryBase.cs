﻿using DesafioMVC.Domain.Entities.Base;
using DesafioMVC.Domain.Interfaces.Base;
using DesafioMVC.Infra.Data.Context;

using Microsoft.EntityFrameworkCore;

using System.Linq.Expressions;

namespace DesafioMVC.Infra.Data.Repository.Base
{
    public class RepositoryBase<TEntity> : IRepositoryBase<TEntity> where TEntity : BaseEntity
    {
        public readonly AppDbContext _appDbContext;

        public RepositoryBase(AppDbContext appContext)
        {
            _appDbContext = appContext;
        }

        public async Task<IEnumerable<TEntity>> ObterAsync()
        {
            return await _appDbContext.Set<TEntity>().AsNoTracking().ToListAsync();
        }

        public async Task<IEnumerable<TEntity>> BuscarAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return await _appDbContext.Set<TEntity>().AsNoTracking().Where(predicate).ToListAsync();
        }

        public async Task AdicionarAsync(TEntity entity)
        {
            await _appDbContext.Set<TEntity>().AddAsync(entity);
        }

        public async Task DeletarAsync(TEntity entity)
        {
            _appDbContext.Set<TEntity>().Remove(entity);
        }

        public async Task AtualizarAsync(TEntity entity)
        {
            _appDbContext.Entry(entity).State = EntityState.Modified;
            _appDbContext.Set<TEntity>().Update(entity);
        }

        public async Task<TEntity?> ObterPorIdAsync(int id)
        {
            return await _appDbContext.Set<TEntity>().FindAsync(id);
        }
    }
}
