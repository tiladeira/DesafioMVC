﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DesafioMVC.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {

        [HttpPost]
        [Route("[action]")]
        public IActionResult Autenticar()
        {
            return Ok();
        }

        [HttpPost]
        [Route("[action]")]
        public IActionResult Registrar()
        {
            return Ok();
        }

        [HttpPost]
        [Route("[action]")]
        public IActionResult LembrarSenha()
        {
            return Ok();
        }
    }
}
