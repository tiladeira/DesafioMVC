﻿using AutoMapper;

using DesafioMVC.API.DTO;
using DesafioMVC.Domain.Entities;
using DesafioMVC.Domain.Interfaces.Services;

using Microsoft.AspNetCore.Mvc;

namespace DesafioMVC.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientesController : ControllerBase
    {
        private readonly IClienteService _clienteService;
        private readonly IMapper _mapper;

        public ClientesController(IClienteService clienteService, IMapper mapper)
        {
            _clienteService = clienteService;
            _mapper = mapper;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var clientes = _clienteService.ObterAsync();
            return Ok(clientes);
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var cliente = _clienteService.ObterPorIdAsync(id);

            if (cliente == null)
                return NotFound();

            return Ok(cliente);
        }

        [HttpPost]
        public IActionResult Post([FromBody] ClienteDto entity)
        {
            var clienteDomain = _mapper.Map<Cliente>(entity);
            _clienteService.AdicionarAsync(clienteDomain);
            return Ok();
        }

        [HttpPut]
        public IActionResult Put([FromBody] ClienteDto entity)
        {
            var clienteDomain = _mapper.Map<Cliente>(entity);
            _clienteService.AtualizarAsync(clienteDomain);
            return Ok();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _clienteService.DeletarAsync(id);
            return Ok();
        }
    }
}
