﻿using DesafioMVC.API.DTO;
using DesafioMVC.Domain.Interfaces.Services;

using Microsoft.AspNetCore.Mvc;

using System.ComponentModel.DataAnnotations;

namespace DesafioMVC.API.Controllers.v1
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly ILoginService _loginService;

        public LoginController(ILoginService loginService)
        {
            _loginService = loginService;
        }

        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login([Required][FromBody] LoginDto model)
        {
            var login = await _loginService.Login(model.Email, model.Password);

            if (login == false)
                return BadRequest("Usuário ou senha inválidos");

            return Ok();
        }
    }
}
