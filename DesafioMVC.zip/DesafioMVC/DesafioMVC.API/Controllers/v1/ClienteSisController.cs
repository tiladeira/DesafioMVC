﻿using AutoMapper;

using Microsoft.AspNetCore.Mvc;

using DesafioMVC.API.DTO;
using DesafioMVC.Domain.Entities;

using DesafioMVC.Domain.Interfaces.Services;

namespace DesafioMVC.API.Controllers.v1
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClienteSisController : ControllerBase
    {
        private readonly IClienteSisService _ClienteSisService;
        private readonly IMapper _mapper;

        public ClienteSisController(IClienteSisService ClienteSisService, IMapper mapper)
        {
            _ClienteSisService = ClienteSisService;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllAsync()
        {
            try
            {
                var result = await _ClienteSisService.GetAllAsync();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetByIdAsync(int id)
        {
            try
            {
                var result = await _ClienteSisService.GetByIdAsync(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> CreateAsync([FromBody] ClienteSisDto ClienteSis)
        {
            try
            {
                var entity = _mapper.Map<ClienteSis>(ClienteSis);
                var result = await _ClienteSisService.CreateAsync(entity);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPut]
        public async Task<IActionResult> UpdateAsync([FromBody] ClienteSisDto ClienteSis)
        {
            try
            {
                var entity = _mapper.Map<ClienteSis>(ClienteSis);
                var result = await _ClienteSisService.UpdateAsync(entity);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteByIdAsync(int id)
        {
            try
            {
                var result = await _ClienteSisService.DeleteByIdAsync(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
    }
}
