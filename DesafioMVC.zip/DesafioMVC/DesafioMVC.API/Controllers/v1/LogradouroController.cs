﻿using AutoMapper;

using Microsoft.AspNetCore.Mvc;

using DesafioMVC.API.DTO;
using DesafioMVC.Domain.Entities;

using DesafioMVC.Domain.Interfaces.Services;

namespace DesafioMVC.API.Controllers.v1
{
    [Route("api/[controller]")]
    [ApiController]
    public class LogradouroController : ControllerBase
    {
        private readonly ILogradouroService _LogradouroService;
        private readonly IMapper _mapper;

        public LogradouroController(ILogradouroService LogradouroService, IMapper mapper)
        {
            _LogradouroService = LogradouroService;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllAsync()
        {
            try
            {
                var result = await _LogradouroService.GetAllAsync();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetByIdAsync(int id)
        {
            try
            {
                var result = await _LogradouroService.GetByIdAsync(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> CreateAsync([FromBody] LogradouroDto Logradouro)
        {
            try
            {
                var entity = _mapper.Map<Logradouro>(Logradouro);
                var result = await _LogradouroService.CreateAsync(entity);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPut]
        public async Task<IActionResult> UpdateAsync([FromBody] LogradouroDto Logradouro)
        {
            try
            {
                var entity = _mapper.Map<Logradouro>(Logradouro);
                var result = await _LogradouroService.UpdateAsync(entity);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteByIdAsync(int id)
        {
            try
            {
                var result = await _LogradouroService.DeleteByIdAsync(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
    }
}
