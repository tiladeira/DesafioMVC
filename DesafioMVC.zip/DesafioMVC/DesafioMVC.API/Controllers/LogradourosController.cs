﻿using AutoMapper;

using DesafioMVC.API.DTO;
using DesafioMVC.Domain.Entities;
using DesafioMVC.Domain.Interfaces.Services;

using Microsoft.AspNetCore.Mvc;

namespace DesafioMVC.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LogradourosController : ControllerBase
    {

        private readonly ILogradouroService _LogradouroService;
        private readonly IMapper _mapper;

        public LogradourosController(ILogradouroService LogradouroService, IMapper mapper)
        {
            _LogradouroService = LogradouroService;
            _mapper = mapper;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var Logradouros = _LogradouroService.ObterAsync();
            return Ok(Logradouros);
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var Logradouro = _LogradouroService.ObterPorIdAsync(id);

            if (Logradouro == null)
                return NotFound();

            return Ok(Logradouro);
        }

        [HttpPost]
        public IActionResult Post([FromBody] LogradouroDto entity)
        {
            var LogradouroDomain = _mapper.Map<Logradouro>(entity);
            _LogradouroService.AdicionarAsync(LogradouroDomain);
            return Ok();
        }

        [HttpPut]
        public IActionResult Put([FromBody] LogradouroDto entity)
        {
            var LogradouroDomain = _mapper.Map<Logradouro>(entity);
            _LogradouroService.AtualizarAsync(LogradouroDomain);
            return Ok();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _LogradouroService.DeletarAsync(id);
            return Ok();
        }
    }
}
