﻿using DesafioMVC.API.DTO;
using DesafioMVC.Domain.Entities;

namespace DesafioMVC.API.AutoMapper
{
    public class MapperProfile : global::AutoMapper.Profile
    {
        public MapperProfile()
        {
            CreateMap<Logradouro, LogradouroDto>().ReverseMap();
            CreateMap<ClienteSis, ClienteSisDto>().ReverseMap();
        }
    }
}
