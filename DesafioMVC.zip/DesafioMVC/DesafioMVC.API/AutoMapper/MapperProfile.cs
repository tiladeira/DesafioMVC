﻿using AutoMapper;

using DesafioMVC.API.DTO;
using DesafioMVC.Domain.Entities;

namespace DesafioMVC.API.AutoMapper
{
    public class MapperProfile : Profile
    {
        public MapperProfile()
        {
            CreateMap<Cliente, ClienteDto>().ReverseMap();
            CreateMap<Logradouro, LogradouroDto>().ReverseMap();
        }
    }
}
