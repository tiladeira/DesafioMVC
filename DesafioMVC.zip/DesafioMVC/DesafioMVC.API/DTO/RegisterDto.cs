﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace DesafioMVC.API.DTO
{
    public class RegisterDto
    {
        [Required(ErrorMessage = "Nome é obrigatório")]
        public string NomeCompleto { get; set; }

        [Required(ErrorMessage = "Celular é obrigatório")]
        public string Celular { get; set; }

        [Required(ErrorMessage = "Email é obrigatório")]
        [EmailAddress(ErrorMessage = "Email inválido")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Senha é obrigatório")]
        public string Password { get; set; }
    }
}
