﻿using System.ComponentModel.DataAnnotations;

namespace DesafioMVC.API.DTO
{
    public class ForgotPasswordDto
    {
        [Required(ErrorMessage = "Email é obrigatório")]
        [EmailAddress(ErrorMessage = "Email inválido")]
        public string Email { get; set; } = null!;
    }
}
