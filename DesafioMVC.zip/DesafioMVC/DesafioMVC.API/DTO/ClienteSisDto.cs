﻿using System.ComponentModel.DataAnnotations;

namespace DesafioMVC.API.DTO
{
    public class ClienteSisDto
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        public string Nome { get; set; } = string.Empty;

        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        public string Senha { get; set; } = string.Empty;

        public string Logotipo { get; set; } = string.Empty;

        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        public bool Status { get; set; }
    }
}
