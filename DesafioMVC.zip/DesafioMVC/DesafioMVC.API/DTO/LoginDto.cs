﻿using System.ComponentModel.DataAnnotations;

namespace DesafioMVC.API.DTO
{
    public class LoginDto
    {
        [Required(ErrorMessage = "Email é obrigatório")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Senha é obrigatório")]
        public string Password { get; set; }
    }
}
