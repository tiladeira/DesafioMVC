﻿using DesafioMVC.Domain.Entities;

namespace DesafioMVC.API.DTO
{
    public class ClienteDto
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Senha { get; set; } = string.Empty;
        public string Logotipo { get; set; } = string.Empty;
        public bool Status { get; set; }

        public ICollection<Logradouro> Logradouros { get; set; }
    }
}
