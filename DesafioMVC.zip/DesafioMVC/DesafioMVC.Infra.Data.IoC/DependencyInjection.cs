﻿using DesafioMVC.Domain.Interfaces.Base;
using DesafioMVC.Domain.Interfaces.Repositories;
using DesafioMVC.Domain.Interfaces.Services;
using DesafioMVC.Domain.Notificacoes;
using DesafioMVC.Domain.Services;
using DesafioMVC.Infra.Data.Context;
using DesafioMVC.Infra.Data.Repository;

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace DesafioMVC.Infra.Data.IoC
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<AppDbContext>(options =>
            {
                options.UseSqlServer(configuration.GetConnectionString("DefaultConnection"));
                options.EnableSensitiveDataLogging();
            });

            services.AddScoped<IUnitOfWorkRepository, UnitOfWorkRepository>();
            services.AddScoped<IClienteRepository, ClienteRepository>();
            services.AddScoped<ILogradouroRepository, LogradouroRepository>();

            services.AddScoped<INotificador, Notificador>();

            return services;
        }

        public static IServiceCollection AddServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IClienteService, ClienteService>();
            services.AddScoped<ILogradouroService, LogradouroService>();

            return services;
        }
    }
}
