﻿using DesafioMVC.Web.Models;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;

namespace DesafioMVC.Web.Controllers
{
    public class ClienteController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public ClienteController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IActionResult> Index()
        {
            var apiClient = _httpClientFactory.CreateClient();
            var response = await apiClient.GetFromJsonAsync<List<ClienteViewModel>>("https://localhost:7238/api/ClienteSis");

            if (response != null)
            {
                return View(response);
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Falha ao consultar API");
                return View(new List<ClienteViewModel>());
            }
        }

        public IActionResult Edit(int id)
        {
            return View();
        }

        public async Task<IActionResult> Create(ClienteViewModel viewModel)
        {
            var apiClient = _httpClientFactory.CreateClient();
            var response = await apiClient.PostAsJsonAsync("https://localhost:7238/api/ClienteSis", viewModel);

            if (response != null)
            {
                return View(response);
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Falha ao consultar API");
                return View(new List<ClienteViewModel>());
            }

        }

        public IActionResult Update(ClienteViewModel viewModel)
        {
            return View();
        }

        public IActionResult Delete(int id)
        {
            return View();
        }
    }
}
