﻿using DesafioMVC.Web.Models;

using Microsoft.AspNetCore.Mvc;

namespace DesafioMVC.Web.Controllers
{
    public class ClienteController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Edit(int id)
        {
            return View();
        }

        public IActionResult Create(ClienteViewModel viewModel)
        {
            return View();
        }

        public IActionResult Update(ClienteViewModel viewModel)
        {
            return View();
        }

        public IActionResult Delete(int id)
        {
            return View();
        }
    }
}
