﻿using DesafioMVC.Web.Models;

using Microsoft.AspNetCore.Mvc;

namespace DesafioMVC.Web.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Index(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                if (model.EMail == "admin@admin.com" && model.Senha == "admin")               
                    return RedirectToAction("Index", "Home");
                else
                {
                    ModelState.AddModelError(string.Empty, "Usuário ou senha não são válidos!");
                    return View(model);
                }
            }

            return View(model);
        }
    }
}
