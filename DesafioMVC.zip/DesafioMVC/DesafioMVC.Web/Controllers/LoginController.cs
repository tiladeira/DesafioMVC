﻿using DesafioMVC.Web.Models;

using Microsoft.AspNetCore.Mvc;

namespace DesafioMVC.Web.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(LoginViewModel model)
        {
            if (model.Username == "admin" && model.Password == "123456")
            {
                HttpContext.Session.SetString("username", model.Username);

                return RedirectToAction("Welcome");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid username or password");
                return View(model);
            }
        }

        public IActionResult Welcome()
        {
            var username = HttpContext.Session.GetString("username");

            return View("Welcome", username);
        }

        public IActionResult Registro(ClienteViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
            }

            return View();
        }
    }
}
