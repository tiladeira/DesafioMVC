﻿using DesafioMVC.Web.Models;

using Microsoft.AspNetCore.Mvc;

using System.Net.Http;

namespace DesafioMVC.Web.Controllers
{
    public class LogradouroController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public LogradouroController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IActionResult> Index()
        {
            var apiClient = _httpClientFactory.CreateClient();
            var response = await apiClient.GetFromJsonAsync<List<LogradouroViewModel>>("https://localhost:7238/api/Logradouro");

            if (response != null)
            {
                return View(response);
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Falha ao consultar API");
                return View(new List<LogradouroViewModel>());
            }
        }

        public IActionResult Edit(int id)
        {
            return View();
        }

        public IActionResult Create(int id)
        {
            return View();
        }

        public IActionResult Update(int id)
        {
            return View();
        }

        public IActionResult Delete(int id)
        {
            return View();
        }
    }
}
