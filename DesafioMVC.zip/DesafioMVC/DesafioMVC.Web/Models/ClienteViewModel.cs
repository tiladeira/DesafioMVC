﻿using System.ComponentModel.DataAnnotations;

namespace DesafioMVC.Web.Models
{
    public class ClienteViewModel
    {
        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        public int Id { get; set; }
        
        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        public string Nome { get; set; }
        
        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        [EmailAddress]
        public string Email { get; set; }
        
        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        [DataType(DataType.Password)]
        public string Senha { get; set;}
        
        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        public string Logotipo { get; set; }
        
        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        public bool Status { get; set; }

        List<LogradouroViewModel> Logradouros { get; set; }
    }
}
