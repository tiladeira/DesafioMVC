﻿using System.ComponentModel.DataAnnotations;

namespace DesafioMVC.Web.Models
{
    public class LogradouroViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        public int ClienteId { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        public string Endereco { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        public string Numero { get; set; }

        public string Complemento { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        public string Bairro { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        public string Cidade { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        public string Cep { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        public string Estado { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        public string Pais { get; set; }
    }
}
