﻿namespace DesafioMVC.Web.Models
{
    public class LogradouroViewModel
    {

    }
}
