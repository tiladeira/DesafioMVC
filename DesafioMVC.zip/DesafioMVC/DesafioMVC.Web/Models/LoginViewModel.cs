﻿using System.ComponentModel.DataAnnotations;

namespace DesafioMVC.Web.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "O campo E-Mail é obrigatório.")]
        public string EMail { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório.")]
        [DataType(DataType.Password)]
        public string Senha { get; set; }
    }
}
