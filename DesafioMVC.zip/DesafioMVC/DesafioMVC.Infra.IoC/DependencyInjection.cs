﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using DesafioMVC.Domain.Interfaces.Repositories;
using DesafioMVC.Domain.Interfaces.Services;
using DesafioMVC.Domain.Services;
using DesafioMVC.Infra.Data.Context;
using DesafioMVC.Infra.Data.Repository;

namespace DesafioMVC.Infra.IoC
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<AppDbContext>(options =>
                options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));

            services.AddScoped<IUnitOfWorkRepository, UnitOfWorkRepository>();

            services.AddScoped<IClienteSisRepository, ClienteSisRepository>();
            services.AddScoped<ILogradouroRepository, LogradouroRepository>();


            return services;
        }

        public static IServiceCollection AddServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IClienteSisService, ClienteSisService>();
            services.AddScoped<ILogradouroService, LogradouroService>();
            services.AddScoped<ILoginService, LoginService>();

            return services;
        }
    }
}
